import React, { useState, useEffect } from 'react';
import $ from 'jquery';
import './App.css';

function CommodityPage () {
  const [commodities, setCommodities] = useState([]);
  const [filterText, setFilterText] = useState('');
  const [showOutOfStockCommodity, setShowOutOfStockCommodity] = useState(true);
  const [newCommodityName, setNewCommodityName] = useState('');
  const [newCommodityCategory, setNewCommodityCategory] = useState('');
  const [newCommodityStatus, setNewCommodityStatus] = useState('');

  function handleFilterTextChange(filterText) {
    setFilterText(filterText);
  }
  
  function handleButtonClick() {
    setShowOutOfStockCommodity(showOutOfStockCommodity => !showOutOfStockCommodity);
  }

  function handleNameChange(name) {
    setNewCommodityName(name);
  }

  function handleCategoryChange(category) {
    setNewCommodityCategory(category);
  }
  
  function handleStatusChange(status) {
    setNewCommodityStatus(status);
  }

  function handleAddFormSubmit(e) {
    alert("Add ("+newCommodityName + ", "+ newCommodityCategory + ", " + newCommodityStatus + ") to the form");
    
    let newData = { 
        "category" : newCommodityCategory, 
        "name" : newCommodityName,
        "status" : newCommodityStatus 
      }

    $.post("http://localhost:3001/users/addcommodity", 
      newData,
      function(data, status){ 
        if (data.msg ===''){
          setCommodities([...commodities, newData]);
          setNewCommodityName('');
          setNewCommodityCategory('');
          setNewCommodityStatus('');
        } else 
          alert(data.msg);
      }
    );
    
    e.preventDefault();
  }
  
  useEffect(() => {
    $.get("http://localhost:3001/users/commodities/",
      function(data) {
        setCommodities(data);
      }, 'json'
    );
  }, []);  //only run once after initial render

  return (
    <div className="App">
      <SearchBar
        filterText={filterText}
        onFilterTextChange={handleFilterTextChange}
      />
      <CommodityTable
        commodities={commodities}
        filterText={filterText}
        showOutOfStockCommodity={showOutOfStockCommodity}       
      />
      <ShowHideButton showOutOfStockCommodity={showOutOfStockCommodity} onButtonClick={handleButtonClick}/>
      <p></p>
      <AddCommodityForm name={newCommodityName}
        category={newCommodityCategory}
        status={newCommodityStatus}
        onNameChange={handleNameChange}
        onCategoryChange={handleCategoryChange}
        onStatusChange={handleStatusChange}
        onFormSubmit={handleAddFormSubmit}
      />
    </div>
  );
}

function SearchBar ( props ) {
  
  function handleFilterTextChange(e) {
    props.onFilterTextChange(e.target.value);
  }
  
  return (
    <form>
      <input
        type="text"
        placeholder="Search..."
        value={props.filterText}
        onChange={handleFilterTextChange}
      />
    </form>
  );
}

function CommodityTable ( props ) {
    const filterText = props.filterText;
    const showOutOfStockCommodity = props.showOutOfStockCommodity;

    var rows = props.commodities.map((commodity) => {
      if (commodity.name.indexOf(filterText) === -1) {
        return null;
      }
	  
      if (showOutOfStockCommodity || commodity.status === "in stock") {
        return (
          <CommodityRow
            commodity={commodity}
            key={commodity.name}
          />
        );
      }
      return null;
    });

    return (
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Category</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>{rows}</tbody>
      </table>
    );
}

function CommodityRow ( props ) {
  const commodity = props.commodity;

  return (
    <tr>
      <td>{commodity.name}</td>
      <td>{commodity.category}</td>
      <td>{commodity.status}</td>
    </tr>
  );
}

function ShowHideButton ( props ) {

  function handleButtonClick() {
    props.onButtonClick();
  }

  return (
    <button onClick={handleButtonClick}>
      {props.showOutOfStockCommodity ? 'Hide Out-of-Stock Commodity' : 'Show Out-of-Stock Commodity'}
    </button>      
  );
}

function AddCommodityForm ( props ) {
  
  function handleInput(event) {
    if (event.target.name === "name") {
      props.onNameChange(event.target.value);
    } else if (event.target.name === "category") {
      props.onCategoryChange(event.target.value);     
    } else {
      props.onStatusChange(event.target.value);
    }   
  }
  
  function handleSubmit(event) {
    props.onFormSubmit(event);
  }
  
  return (
    <form onSubmit={handleSubmit}>
      <label>Name: </label>
      <input name="name" type="text" 
        placeholder="name"
        value={props.name} 
        onChange={handleInput}/>
      <br />
      <label>Category: </label>
      <input name="category" type="text" 
        placeholder="category"
        value={props.category} 
        onChange={handleInput}/>
      <br />
      <label>Status: </label>
      <select name="select" 
        value={props.status}
        onChange={handleInput}>
        <option value=""></option>
        <option value="in stock">in stock</option>
        <option value="out of stock">out of stock</option>
      </select>
      <br />
      <input type="submit" 
        value="Submit"/>
    </form>
  )

}

export default CommodityPage;
